# Quick Start Guide - Lexington & Associates Website

## Getting Started

### 1. Local Development
```bash
# Navigate to the project directory
cd legal-website

# Start a local web server
python3 -m http.server 8000

# Open in browser
# Visit http://localhost:8000
```

### 2. File Overview

| File | Purpose |
|------|---------|
| `index.html` | Main website structure and content |
| `css/styles.css` | All styling and responsive design |
| `js/script.js` | Interactive features and functionality |
| `README.md` | Comprehensive documentation |
| `QUICKSTART.md` | This file |

### 3. Key Features to Test

- **Disclaimer Modal**: Appears on first visit; click "I Agree" to proceed
- **Navigation**: Click links in navbar to scroll to sections
- **Responsive Design**: Resize browser to see mobile layout
- **Contact Form**: Fill and submit the contact form
- **Hover Effects**: Hover over cards to see animations
- **Mobile Menu**: On mobile, click hamburger icon for menu

### 4. Customization Steps

#### Update Firm Information
Edit `index.html` and find:
- Line ~30: Firm name and tagline
- Line ~100: Hero section headline
- Line ~150: About section content
- Line ~280: Contact information

#### Change Colors
Edit `css/styles.css` and modify:
```css
:root {
    --primary-color: #1a3a52;      /* Main blue */
    --secondary-color: #c9a961;    /* Gold accents */
    --accent-color: #2c5aa0;       /* Link blue */
}
```

#### Add New Practice Areas
In `index.html`, find the Expertise section and add:
```html
<div class="expertise-card">
    <div class="expertise-icon">
        <i class="fas fa-icon-name"></i>
    </div>
    <h3>Practice Area Name</h3>
    <p>Description of the practice area</p>
</div>
```

#### Add New Team Members
In `index.html`, find the People section and add:
```html
<div class="people-card">
    <div class="people-image">
        <i class="fas fa-user-tie"></i>
    </div>
    <h3>Attorney Name</h3>
    <p class="role">Position Title</p>
    <p class="bio">Bio description</p>
    <p class="expertise">Expertise: Area 1, Area 2, Area 3</p>
</div>
```

### 5. Deployment

#### Option A: GitHub Pages
1. Create a GitHub repository
2. Push all files to the repository
3. Enable GitHub Pages in settings
4. Website will be live at `https://username.github.io/legal-website`

#### Option B: Web Hosting
1. Upload files via FTP/SFTP to your hosting provider
2. Ensure all files are in the public_html directory
3. Visit your domain to access the website

#### Option C: Docker
```bash
# Create a Dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY . .
CMD ["python", "-m", "http.server", "8000"]

# Build and run
docker build -t legal-website .
docker run -p 8000:8000 legal-website
```

### 6. Font Awesome Icons

The website uses Font Awesome icons. To change icons:
1. Visit [Font Awesome](https://fontawesome.com/icons)
2. Find the icon you want
3. Replace the icon class in HTML

Example:
```html
<!-- Current -->
<i class="fas fa-briefcase"></i>

<!-- Change to -->
<i class="fas fa-gavel"></i>
```

### 7. Troubleshooting

**Disclaimer modal not appearing?**
- Clear browser localStorage: Open DevTools → Application → Local Storage → Clear All
- Refresh the page

**Styles not loading?**
- Check that `css/styles.css` is in the correct directory
- Verify file paths in `index.html`

**Icons not showing?**
- Ensure Font Awesome CDN link is working
- Check internet connection

**Mobile menu not working?**
- Verify `js/script.js` is loaded
- Check browser console for errors

### 8. Browser Testing

Test on:
- Chrome (Desktop & Mobile)
- Firefox (Desktop & Mobile)
- Safari (Desktop & Mobile)
- Edge (Desktop)

### 9. Performance Tips

- Minify CSS and JavaScript for production
- Optimize images before uploading
- Enable gzip compression on server
- Use a CDN for faster content delivery
- Implement caching headers

### 10. Next Steps

1. **Add Blog**: Create a blog section for thought leadership
2. **Client Portal**: Build a secure client login area
3. **Case Studies**: Add detailed case studies and success stories
4. **Team Expansion**: Add more attorney profiles
5. **SEO Optimization**: Add meta descriptions and keywords
6. **Analytics**: Integrate Google Analytics
7. **Email Integration**: Set up contact form email notifications
8. **SSL Certificate**: Ensure HTTPS for security

## Support

For issues or questions:
1. Check the README.md for detailed documentation
2. Review the code comments in HTML, CSS, and JavaScript
3. Test in different browsers
4. Check browser console for error messages

## Version History

- **v1.0** (June 2, 2026): Initial release with core features

---

Happy customizing! 🎉
