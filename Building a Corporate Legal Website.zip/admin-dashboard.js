// ==========================================
// ADMIN DASHBOARD JAVASCRIPT
// ==========================================

// Configuration
const ADMIN_PASSWORD = 'admin123'; // Default password - CHANGE THIS!
const API_BASE_URL = 'https://lexington-backend.herokuapp.com/api';
let isLoggedIn = false;
let currentTab = 'overview';

// ==========================================
// AUTHENTICATION
// ==========================================

function handleLogin(event) {
    event.preventDefault();
    
    const password = document.getElementById('password').value;
    
    if (password === ADMIN_PASSWORD) {
        isLoggedIn = true;
        localStorage.setItem('adminLoggedIn', 'true');
        localStorage.setItem('adminLoginTime', new Date().getTime());
        
        // Hide login modal and show dashboard
        document.getElementById('loginModal').classList.add('hidden');
        document.getElementById('dashboardContent').classList.remove('hidden');
        
        // Initialize dashboard
        initializeDashboard();
        
        // Clear password field
        document.getElementById('password').value = '';
    } else {
        alert('Invalid password. Please try again.');
    }
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        isLoggedIn = false;
        localStorage.removeItem('adminLoggedIn');
        localStorage.removeItem('adminLoginTime');
        
        // Show login modal and hide dashboard
        document.getElementById('loginModal').classList.remove('hidden');
        document.getElementById('dashboardContent').classList.add('hidden');
        
        // Clear form
        document.getElementById('password').value = '';
    }
}

function checkAuthentication() {
    const loggedIn = localStorage.getItem('adminLoggedIn');
    const loginTime = localStorage.getItem('adminLoginTime');
    
    if (loggedIn === 'true' && loginTime) {
        // Check if session is still valid (24 hours)
        const now = new Date().getTime();
        const elapsed = now - parseInt(loginTime);
        const maxSessionTime = 24 * 60 * 60 * 1000; // 24 hours
        
        if (elapsed < maxSessionTime) {
            isLoggedIn = true;
            document.getElementById('loginModal').classList.add('hidden');
            document.getElementById('dashboardContent').classList.remove('hidden');
            return true;
        } else {
            localStorage.removeItem('adminLoggedIn');
            localStorage.removeItem('adminLoginTime');
        }
    }
    
    return false;
}

// ==========================================
// DASHBOARD INITIALIZATION
// ==========================================

function initializeDashboard() {
    console.log('Initializing dashboard...');
    
    // Load initial data
    loadDashboardData();
    
    // Set up auto-refresh
    setInterval(loadDashboardData, 60000); // Refresh every minute
    
    console.log('Dashboard initialized');
}

function loadDashboardData() {
    // Load stats
    updateStats();
    
    // Load activity
    loadActivity();
    
    // Check deployment status
    checkDeploymentStatus();
}

// ==========================================
// TAB SWITCHING
// ==========================================

function switchTab(tabName) {
    event.preventDefault();
    
    // Hide all tabs
    const tabs = document.querySelectorAll('.tab-pane');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    // Remove active class from nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => item.classList.remove('active'));
    
    // Show selected tab
    const selectedTab = document.getElementById(tabName);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Mark nav item as active
    event.target.closest('.nav-item')?.classList.add('active');
    
    // Update page title
    updatePageTitle(tabName);
    
    // Load tab-specific data
    loadTabData(tabName);
    
    currentTab = tabName;
}

function updatePageTitle(tabName) {
    const titles = {
        'overview': { title: 'Overview', subtitle: 'Dashboard Overview' },
        'deployment': { title: 'Deployment Status', subtitle: 'Check your deployment status' },
        'setup': { title: 'Setup Progress', subtitle: 'Track your setup progress' },
        'content': { title: 'Content Management', subtitle: 'Manage website content' },
        'submissions': { title: 'Contact Submissions', subtitle: 'View contact form submissions' },
        'analytics': { title: 'Analytics', subtitle: 'Website analytics and metrics' },
        'settings': { title: 'Settings', subtitle: 'Configure dashboard settings' }
    };
    
    const titleData = titles[tabName] || titles['overview'];
    document.getElementById('pageTitle').textContent = titleData.title;
    document.getElementById('pageSubtitle').textContent = titleData.subtitle;
}

function loadTabData(tabName) {
    switch(tabName) {
        case 'deployment':
            checkDeploymentStatus();
            break;
        case 'submissions':
            loadContactSubmissions();
            break;
        case 'analytics':
            loadAnalytics();
            break;
        case 'setup':
            updateSetupProgress();
            break;
    }
}

// ==========================================
// OVERVIEW TAB
// ==========================================

function updateStats() {
    // Get data from localStorage (in production, this would come from backend)
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    const teamMembers = 4; // Sample data
    
    document.getElementById('statSubmissions').textContent = submissions.length;
    document.getElementById('statTeam').textContent = teamMembers;
    document.getElementById('statDeployment').textContent = '✅ Online';
    document.getElementById('statSetup').textContent = '75%';
}

function loadActivity() {
    const activities = [
        {
            icon: 'fa-envelope',
            text: 'New contact form submission received',
            time: '2 hours ago'
        },
        {
            icon: 'fa-check-circle',
            text: 'Website deployed to GitHub Pages',
            time: '5 hours ago'
        },
        {
            icon: 'fa-cog',
            text: 'Backend service restarted',
            time: '1 day ago'
        }
    ];
    
    const activityList = document.getElementById('activityList');
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <i class="fas ${activity.icon}"></i>
            <div class="activity-info">
                <p>${activity.text}</p>
                <span>${activity.time}</span>
            </div>
        </div>
    `).join('');
}

// ==========================================
// DEPLOYMENT STATUS TAB
// ==========================================

function checkDeploymentStatus() {
    console.log('Checking deployment status...');
    
    // Check GitHub Pages
    checkGitHubStatus();
    
    // Check Heroku
    checkHerokuStatus();
    
    // Check Email Service
    checkEmailService();
}

function checkGitHubStatus() {
    // In production, this would make an actual API call
    const githubUrl = localStorage.getItem('githubUrl') || 'https://username.github.io/lexington-legal-website';
    document.getElementById('githubUrl').textContent = githubUrl;
    document.getElementById('githubStatus').textContent = '✅ Deployed';
    document.getElementById('githubDeploy').textContent = '2 hours ago';
}

function checkHerokuStatus() {
    const herokuUrl = localStorage.getItem('herokuUrl') || 'https://lexington-backend.herokuapp.com';
    document.getElementById('herokuUrl').textContent = herokuUrl;
    document.getElementById('herokuStatus').textContent = '✅ Running';
    document.getElementById('herokuDeploy').textContent = '3 hours ago';
    document.getElementById('herokuUptime').textContent = '99.9%';
}

function checkEmailService() {
    document.getElementById('emailStatus').textContent = '✅ Connected';
    document.getElementById('emailsSent').textContent = '12';
    document.getElementById('deliveryRate').textContent = '99.8%';
}

function testEmailService() {
    alert('Test email sent! Check your inbox.');
    // In production, this would call the backend API
}

// ==========================================
// SETUP PROGRESS TAB
// ==========================================

function updateSetupProgress() {
    const setupProgress = JSON.parse(localStorage.getItem('setupProgress') || '{"completed": 4, "total": 6}');
    const percentage = Math.round((setupProgress.completed / setupProgress.total) * 100);
    
    document.getElementById('progressFill').style.width = percentage + '%';
    document.getElementById('progressText').textContent = percentage + '% Complete';
}

function markStepComplete() {
    const setupProgress = JSON.parse(localStorage.getItem('setupProgress') || '{"completed": 4, "total": 6}');
    
    if (setupProgress.completed < setupProgress.total) {
        setupProgress.completed++;
        localStorage.setItem('setupProgress', JSON.stringify(setupProgress));
        updateSetupProgress();
        alert('Step marked as complete!');
    } else {
        alert('All steps are already completed!');
    }
}

function viewSetupGuide() {
    window.open('SETUP_INSTRUCTIONS.md', '_blank');
}

// ==========================================
// CONTENT MANAGEMENT TAB
// ==========================================

function switchContentTab(tabName) {
    // Hide all content tabs
    const contentTabs = document.querySelectorAll('.content-tab-content');
    contentTabs.forEach(tab => tab.classList.remove('active'));
    
    // Remove active class from buttons
    const buttons = document.querySelectorAll('.content-tab-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    
    // Show selected content tab
    const selectedTab = document.getElementById(tabName + 'Content');
    if (selectedTab) {
        selectedTab.classList.add('active');
    }
    
    // Mark button as active
    event.target.classList.add('active');
}

function saveContent(section) {
    alert(`${section} content saved successfully!`);
    // In production, this would save to backend
}

function editPracticeArea(id) {
    alert(`Edit practice area: ${id}`);
}

function addPracticeArea() {
    alert('Add new practice area form would open here');
}

function editTeamMember(id) {
    alert(`Edit team member: ${id}`);
}

function addTeamMember() {
    alert('Add new team member form would open here');
}

function editInsight(id) {
    alert(`Edit insight: ${id}`);
}

function addInsight() {
    alert('Add new insight form would open here');
}

// ==========================================
// CONTACT SUBMISSIONS TAB
// ==========================================

function loadContactSubmissions() {
    // Get submissions from localStorage
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    
    if (submissions.length === 0) {
        console.log('No submissions found');
        return;
    }
    
    // Display submissions
    const submissionsList = document.querySelector('.submissions-list');
    submissionsList.innerHTML = submissions.map((submission, index) => `
        <div class="submission-item">
            <div class="submission-header">
                <h4>${submission.name}</h4>
                <span class="submission-date">${formatDate(submission.date)}</span>
            </div>
            <p class="submission-subject"><strong>Subject:</strong> ${submission.subject}</p>
            <p class="submission-email"><strong>Email:</strong> ${submission.email}</p>
            <p class="submission-message">${submission.message}</p>
            <div class="submission-actions">
                <button class="btn btn-sm btn-primary" onclick="viewSubmission(${index})">View</button>
                <button class="btn btn-sm btn-secondary" onclick="archiveSubmission(${index})">Archive</button>
            </div>
        </div>
    `).join('');
}

function viewSubmission(id) {
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    const submission = submissions[id];
    
    if (submission) {
        alert(`
Name: ${submission.name}
Email: ${submission.email}
Subject: ${submission.subject}

Message:
${submission.message}
        `);
    }
}

function archiveSubmission(id) {
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    submissions.splice(id, 1);
    localStorage.setItem('contactSubmissions', JSON.stringify(submissions));
    loadContactSubmissions();
    alert('Submission archived');
}

// ==========================================
// ANALYTICS TAB
// ==========================================

function loadAnalytics() {
    console.log('Loading analytics...');
    // Analytics data would be loaded from backend
}

// ==========================================
// SETTINGS TAB
// ==========================================

function changePassword() {
    const newPassword = document.getElementById('newPassword').value;
    
    if (!newPassword) {
        alert('Please enter a new password');
        return;
    }
    
    if (newPassword.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    // In production, this would be hashed and stored securely
    localStorage.setItem('adminPassword', newPassword);
    alert('Password changed successfully!');
    document.getElementById('newPassword').value = '';
}

function saveEmailSettings() {
    alert('Email settings saved successfully!');
}

function saveDeploymentSettings() {
    alert('Deployment settings saved successfully!');
}

function exportData() {
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    
    // Create CSV
    let csv = 'Name,Email,Subject,Date\n';
    submissions.forEach(submission => {
        csv += `"${submission.name}","${submission.email}","${submission.subject}","${submission.date}"\n`;
    });
    
    // Download CSV
    downloadCSV(csv, 'submissions.csv');
}

function backupDatabase() {
    const backup = {
        submissions: JSON.parse(localStorage.getItem('contactSubmissions') || '[]'),
        setupProgress: JSON.parse(localStorage.getItem('setupProgress') || '{}'),
        timestamp: new Date().toISOString()
    };
    
    downloadJSON(backup, 'backup.json');
}

function downloadCSV(csv, filename) {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

function downloadJSON(data, filename) {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:application/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2)));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 60) return `${minutes} minutes ago`;
    if (hours < 24) return `${hours} hours ago`;
    if (days < 7) return `${days} days ago`;
    
    return date.toLocaleDateString();
}

// ==========================================
// INITIALIZATION
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Admin Dashboard Loading...');
    
    // Check authentication
    if (checkAuthentication()) {
        initializeDashboard();
    } else {
        document.getElementById('loginModal').classList.remove('hidden');
        document.getElementById('dashboardContent').classList.add('hidden');
    }
    
    // Set up event listeners
    setupEventListeners();
});

function setupEventListeners() {
    // Handle keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Ctrl+L to logout
        if (e.ctrlKey && e.key === 'l') {
            handleLogout();
        }
    });
    
    // Handle window close warning
    window.addEventListener('beforeunload', (e) => {
        if (isLoggedIn) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
}

// ==========================================
// CONTACT FORM INTEGRATION
// ==========================================

// This function is called from the main website when a contact form is submitted
function saveContactSubmission(formData) {
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    
    submissions.push({
        name: formData.name,
        email: formData.email,
        subject: formData.subject,
        message: formData.message,
        date: new Date().toISOString()
    });
    
    localStorage.setItem('contactSubmissions', JSON.stringify(submissions));
    
    console.log('Contact submission saved to dashboard');
}

// ==========================================
// DEBUG FUNCTIONS
// ==========================================

function debugLoadSampleData() {
    const sampleSubmissions = [
        {
            name: 'John Smith',
            email: 'john@example.com',
            subject: 'Corporate M&A Inquiry',
            message: 'Interested in discussing a potential acquisition...',
            date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
        },
        {
            name: 'Sarah Johnson',
            email: 'sarah@company.com',
            subject: 'Banking & Finance Services',
            message: 'Looking for project finance advisory for infrastructure project...',
            date: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString()
        }
    ];
    
    localStorage.setItem('contactSubmissions', JSON.stringify(sampleSubmissions));
    console.log('Sample data loaded');
}

console.log('Admin Dashboard JavaScript Loaded');
