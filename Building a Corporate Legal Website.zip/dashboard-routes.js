const express = require('express');
const router = express.Router();

// ==========================================
// DASHBOARD API ROUTES
// ==========================================

// Middleware for dashboard authentication
function dashboardAuth(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({
            success: false,
            message: 'Unauthorized access'
        });
    }
    
    // In production, verify JWT token
    // For now, just check if token exists
    next();
}

// ==========================================
// DASHBOARD STATS ENDPOINTS
// ==========================================

// Get dashboard overview stats
router.get('/dashboard/stats', dashboardAuth, (req, res) => {
    try {
        const stats = {
            totalSubmissions: 45,
            thisMonth: 18,
            deploymentStatus: 'online',
            setupProgress: 75,
            teamMembers: 4,
            emailsSent: 12,
            deliveryRate: 99.8,
            uptime: 99.9
        };
        
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching stats',
            error: error.message
        });
    }
});

// ==========================================
// DEPLOYMENT STATUS ENDPOINTS
// ==========================================

// Get GitHub Pages status
router.get('/dashboard/deployment/github', dashboardAuth, (req, res) => {
    try {
        const status = {
            platform: 'GitHub Pages',
            url: process.env.GITHUB_PAGES_URL || 'https://username.github.io/lexington-legal-website',
            status: 'online',
            lastDeploy: '2 hours ago',
            repository: 'lexington-legal-website',
            branch: 'master'
        };
        
        res.json({
            success: true,
            data: status
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching GitHub status',
            error: error.message
        });
    }
});

// Get Heroku backend status
router.get('/dashboard/deployment/heroku', dashboardAuth, (req, res) => {
    try {
        const status = {
            platform: 'Heroku',
            url: process.env.HEROKU_APP_URL || 'https://lexington-backend.herokuapp.com',
            status: 'running',
            lastDeploy: '3 hours ago',
            uptime: 99.9,
            dynoType: 'free'
        };
        
        res.json({
            success: true,
            data: status
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching Heroku status',
            error: error.message
        });
    }
});

// Get email service status
router.get('/dashboard/deployment/email', dashboardAuth, (req, res) => {
    try {
        const status = {
            service: 'Gmail SMTP',
            status: 'connected',
            emailsSentToday: 12,
            deliveryRate: 99.8,
            lastError: null
        };
        
        res.json({
            success: true,
            data: status
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching email status',
            error: error.message
        });
    }
});

// ==========================================
// CONTACT SUBMISSIONS ENDPOINTS
// ==========================================

// Get all contact submissions
router.get('/dashboard/submissions', dashboardAuth, (req, res) => {
    try {
        // In production, fetch from database
        const submissions = [
            {
                id: 1,
                name: 'John Smith',
                email: 'john@example.com',
                subject: 'Corporate M&A Inquiry',
                message: 'Interested in discussing a potential acquisition...',
                date: new Date(Date.now() - 2 * 60 * 60 * 1000),
                status: 'new'
            },
            {
                id: 2,
                name: 'Sarah Johnson',
                email: 'sarah@company.com',
                subject: 'Banking & Finance Services',
                message: 'Looking for project finance advisory...',
                date: new Date(Date.now() - 5 * 60 * 60 * 1000),
                status: 'read'
            }
        ];
        
        res.json({
            success: true,
            data: submissions,
            count: submissions.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching submissions',
            error: error.message
        });
    }
});

// Get single submission
router.get('/dashboard/submissions/:id', dashboardAuth, (req, res) => {
    try {
        const { id } = req.params;
        
        // In production, fetch from database
        const submission = {
            id: parseInt(id),
            name: 'John Smith',
            email: 'john@example.com',
            subject: 'Corporate M&A Inquiry',
            message: 'Interested in discussing a potential acquisition...',
            date: new Date(),
            status: 'read'
        };
        
        res.json({
            success: true,
            data: submission
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching submission',
            error: error.message
        });
    }
});

// Archive submission
router.post('/dashboard/submissions/:id/archive', dashboardAuth, (req, res) => {
    try {
        const { id } = req.params;
        
        // In production, update database
        res.json({
            success: true,
            message: `Submission ${id} archived successfully`
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error archiving submission',
            error: error.message
        });
    }
});

// ==========================================
// ANALYTICS ENDPOINTS
// ==========================================

// Get website traffic analytics
router.get('/dashboard/analytics/traffic', dashboardAuth, (req, res) => {
    try {
        const analytics = {
            totalViews: 2450,
            uniqueVisitors: 1200,
            avgSessionDuration: '3m 45s',
            bounceRate: 32.5,
            topPages: [
                { page: 'Home', views: 850 },
                { page: 'Expertise', views: 620 },
                { page: 'About', views: 480 },
                { page: 'Contact', views: 320 }
            ],
            devices: {
                desktop: 55,
                mobile: 38,
                tablet: 7
            }
        };
        
        res.json({
            success: true,
            data: analytics
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching analytics',
            error: error.message
        });
    }
});

// Get contact form analytics
router.get('/dashboard/analytics/contact-forms', dashboardAuth, (req, res) => {
    try {
        const analytics = {
            totalSubmissions: 45,
            thisMonth: 18,
            conversionRate: 3.2,
            avgResponseTime: '2.5 hours',
            submissionsBySource: {
                direct: 25,
                organic: 15,
                referral: 5
            }
        };
        
        res.json({
            success: true,
            data: analytics
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching contact form analytics',
            error: error.message
        });
    }
});

// ==========================================
// CONTENT MANAGEMENT ENDPOINTS
// ==========================================

// Get all content sections
router.get('/dashboard/content', dashboardAuth, (req, res) => {
    try {
        const content = {
            about: {
                firmName: 'Lexington & Associates',
                tagline: 'Corporate Legal Excellence',
                description: 'Lexington & Associates is a premier full-service corporate law firm...'
            },
            practiceAreas: [
                { id: 1, name: 'Corporate & M&A', description: 'Mergers, acquisitions, joint ventures...' },
                { id: 2, name: 'Capital Markets', description: 'IPOs, debt offerings, securities...' },
                { id: 3, name: 'Banking & Finance', description: 'Project finance, structured finance...' }
            ],
            teamMembers: [
                { id: 1, name: 'Rajesh Kumar', role: 'Managing Partner', expertise: ['Corporate Law', 'M&A'] },
                { id: 2, name: 'Priya Sharma', role: 'Senior Partner', expertise: ['Dispute Resolution', 'Arbitration'] }
            ]
        };
        
        res.json({
            success: true,
            data: content
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching content',
            error: error.message
        });
    }
});

// Update content section
router.post('/dashboard/content/:section', dashboardAuth, (req, res) => {
    try {
        const { section } = req.params;
        const { data } = req.body;
        
        // In production, save to database
        res.json({
            success: true,
            message: `${section} content updated successfully`,
            data: data
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating content',
            error: error.message
        });
    }
});

// ==========================================
// SETUP PROGRESS ENDPOINTS
// ==========================================

// Get setup progress
router.get('/dashboard/setup-progress', dashboardAuth, (req, res) => {
    try {
        const progress = {
            completed: 4,
            total: 6,
            percentage: 67,
            steps: [
                { id: 1, name: 'Create GitHub Account', completed: true },
                { id: 2, name: 'Upload Files to GitHub', completed: true },
                { id: 3, name: 'Enable GitHub Pages', completed: true },
                { id: 4, name: 'Create Heroku Account', completed: true },
                { id: 5, name: 'Configure Email Service', completed: false },
                { id: 6, name: 'Test Everything', completed: false }
            ]
        };
        
        res.json({
            success: true,
            data: progress
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching setup progress',
            error: error.message
        });
    }
});

// Mark setup step as complete
router.post('/dashboard/setup-progress/:stepId/complete', dashboardAuth, (req, res) => {
    try {
        const { stepId } = req.params;
        
        // In production, update database
        res.json({
            success: true,
            message: `Step ${stepId} marked as complete`
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating setup progress',
            error: error.message
        });
    }
});

// ==========================================
// SETTINGS ENDPOINTS
// ==========================================

// Get dashboard settings
router.get('/dashboard/settings', dashboardAuth, (req, res) => {
    try {
        const settings = {
            firmEmail: process.env.FIRM_EMAIL || 'info@lexingtonassociates.com',
            emailProvider: 'Gmail SMTP',
            githubUrl: process.env.GITHUB_REPOSITORY || 'https://github.com/username/lexington-legal-website',
            herokuUrl: process.env.HEROKU_APP_URL || 'https://lexington-backend.herokuapp.com',
            autoBackup: true,
            backupFrequency: 'daily'
        };
        
        res.json({
            success: true,
            data: settings
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching settings',
            error: error.message
        });
    }
});

// Update dashboard settings
router.post('/dashboard/settings', dashboardAuth, (req, res) => {
    try {
        const { settings } = req.body;
        
        // In production, save to database
        res.json({
            success: true,
            message: 'Settings updated successfully',
            data: settings
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error updating settings',
            error: error.message
        });
    }
});

// Export data
router.get('/dashboard/export/submissions', dashboardAuth, (req, res) => {
    try {
        // In production, fetch from database and generate CSV
        const csv = 'Name,Email,Subject,Date\n' +
                    '"John Smith","john@example.com","Corporate M&A Inquiry","2026-06-01"\n' +
                    '"Sarah Johnson","sarah@company.com","Banking & Finance Services","2026-05-31"\n';
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="submissions.csv"');
        res.send(csv);
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error exporting data',
            error: error.message
        });
    }
});

// Backup database
router.post('/dashboard/backup', dashboardAuth, (req, res) => {
    try {
        const backup = {
            timestamp: new Date().toISOString(),
            submissions: [],
            settings: {},
            content: {}
        };
        
        // In production, create actual backup
        res.json({
            success: true,
            message: 'Backup created successfully',
            data: backup
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error creating backup',
            error: error.message
        });
    }
});

module.exports = router;
