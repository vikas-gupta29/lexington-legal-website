const express = require('express');
const cors = require('cors');
const nodemailer = require('nodemailer');
require('dotenv').config();

const dashboardRoutes = require('./dashboard-routes');

const app = express();

// Middleware
app.use(cors({
    origin: '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Email transporter configuration
// Using Gmail as the email service (you can change this to your preferred service)
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER || 'your-email@gmail.com',
        pass: process.env.EMAIL_PASSWORD || 'your-app-password'
    }
});

// Test email connection
transporter.verify((error, success) => {
    if (error) {
        console.log('Email service error:', error);
    } else {
        console.log('Email service ready');
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'Backend service is running' });
});

// Dashboard routes
app.use('/api', dashboardRoutes);

// Contact form submission endpoint
app.post('/api/contact', async (req, res) => {
    try {
        // Log submission for dashboard
        console.log('New contact form submission received');
        
        const { name, email, subject, message } = req.body;

        // Validate input
        if (!name || !email || !subject || !message) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid email address'
            });
        }

        // Email to firm
        const firmMailOptions = {
            from: process.env.EMAIL_USER || 'noreply@lexingtonassociates.com',
            to: process.env.FIRM_EMAIL || 'info@lexingtonassociates.com',
            subject: `New Contact Form Submission: ${subject}`,
            html: `
                <h2>New Contact Form Submission</h2>
                <p><strong>Name:</strong> ${escapeHtml(name)}</p>
                <p><strong>Email:</strong> ${escapeHtml(email)}</p>
                <p><strong>Subject:</strong> ${escapeHtml(subject)}</p>
                <p><strong>Message:</strong></p>
                <p>${escapeHtml(message).replace(/\n/g, '<br>')}</p>
                <hr>
                <p><small>This is an automated message from the Lexington & Associates website contact form.</small></p>
            `
        };

        // Confirmation email to user
        const userMailOptions = {
            from: process.env.EMAIL_USER || 'noreply@lexingtonassociates.com',
            to: email,
            subject: 'We received your message - Lexington & Associates',
            html: `
                <h2>Thank you for contacting us</h2>
                <p>Dear ${escapeHtml(name)},</p>
                <p>We have received your inquiry and appreciate you reaching out to Lexington & Associates.</p>
                <p><strong>Your Message Details:</strong></p>
                <p><strong>Subject:</strong> ${escapeHtml(subject)}</p>
                <p><strong>Message:</strong></p>
                <p>${escapeHtml(message).replace(/\n/g, '<br>')}</p>
                <hr>
                <p>Our team will review your message and get back to you shortly at this email address.</p>
                <p>Best regards,<br>
                <strong>Lexington & Associates</strong><br>
                Corporate Legal Excellence<br>
                123 Business Park, Bandra Kurla Complex<br>
                Mumbai, Maharashtra 400051, India<br>
                Phone: +91 22 1234 5678<br>
                Email: info@lexingtonassociates.com</p>
                <hr>
                <p><small>This is an automated response. Please do not reply to this email.</small></p>
            `
        };

        // Send emails
        await transporter.sendMail(firmMailOptions);
        await transporter.sendMail(userMailOptions);

        // Save submission data for dashboard (in production, save to database)
        const submission = {
            name: name,
            email: email,
            subject: subject,
            message: message,
            timestamp: new Date().toISOString(),
            status: 'new'
        };
        
        console.log('Submission saved:', submission);

        return res.status(200).json({
            success: true,
            message: 'Your message has been sent successfully. We will get back to you shortly.',
            submissionId: Date.now()
        });

    } catch (error) {
        console.error('Error sending email:', error);
        return res.status(500).json({
            success: false,
            message: 'An error occurred while sending your message. Please try again later.',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// Dashboard authentication endpoint
app.post('/api/dashboard/login', (req, res) => {
    const { password } = req.body;
    const correctPassword = process.env.DASHBOARD_PASSWORD || 'admin123';
    
    if (password === correctPassword) {
        res.json({
            success: true,
            message: 'Login successful',
            token: correctPassword
        });
    } else {
        res.status(401).json({
            success: false,
            message: 'Invalid password'
        });
    }
});

console.log('Dashboard authentication endpoint loaded');

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
        success: false,
        message: 'An unexpected error occurred'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: 'Endpoint not found'
    });
});

// CORS preflight
app.options('*', cors());

// Helper function to escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

// Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`\n========================================`);
    console.log(`Backend server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`========================================`);
    console.log(`API Endpoints:`);
    console.log(`  - Contact form: POST /api/contact`);
    console.log(`  - Dashboard login: POST /api/dashboard/login`);
    console.log(`  - Dashboard stats: GET /api/dashboard/stats`);
    console.log(`  - Dashboard submissions: GET /api/dashboard/submissions`);
    console.log(`  - Dashboard analytics: GET /api/dashboard/analytics/*`);
    console.log(`========================================\n`);
});

console.log('Backend server fully configured');

module.exports = app;
