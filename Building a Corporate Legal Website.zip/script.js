// ==========================================
// CORPORATE LEGAL WEBSITE - JAVASCRIPT
// ==========================================

// API endpoint for contact form submissions
const API_ENDPOINT = process.env.REACT_APP_API_URL || 'https://lexington-backend.herokuapp.com/api/contact';

// Disclaimer Modal Functions
function acceptDisclaimer() {
    const modal = document.getElementById('disclaimerModal');
    const mainContent = document.getElementById('mainContent');
    
    // Store acceptance in localStorage
    localStorage.setItem('disclaimerAccepted', 'true');
    
    // Hide modal and show main content
    modal.classList.add('hidden');
    mainContent.classList.remove('hidden');
    
    // Smooth transition
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

function rejectDisclaimer() {
    alert('You must accept the disclaimer to access this website.');
}

// Check if disclaimer was already accepted
function checkDisclaimerAcceptance() {
    const accepted = localStorage.getItem('disclaimerAccepted');
    if (accepted === 'true') {
        document.getElementById('disclaimerModal').classList.add('hidden');
        document.getElementById('mainContent').classList.remove('hidden');
    }
}

// Mobile Menu Toggle
function setupMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            
            // Animate hamburger
            const spans = hamburger.querySelectorAll('span');
            if (navMenu.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(10px, 10px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -7px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });
    }
    
    // Close menu when a link is clicked
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            const spans = hamburger.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        });
    });
}

// Contact Form Handler with Email Integration
function handleContactForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.textContent;
    
    // Get form values
    const name = form.querySelector('input[placeholder="Your Name"]').value.trim();
    const email = form.querySelector('input[placeholder="Your Email"]').value.trim();
    const subject = form.querySelector('input[placeholder="Subject"]').value.trim();
    const message = form.querySelector('textarea').value.trim();
    
    // Validate form
    if (!name || !email || !subject || !message) {
        alert('Please fill in all fields');
        return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
    }
    
    // Disable button and show loading state
    submitButton.disabled = true;
    submitButton.textContent = 'SENDING...';
    
    // Prepare form data
    const formData = {
        name: name,
        email: email,
        subject: subject,
        message: message
    };
    
    // Send to backend
    fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            alert(`Thank you for your message, ${name}!\n\n${data.message}\n\nBest regards,\nLexington & Associates`);
            
            // Reset form
            form.reset();
            
            // Reset button
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
        } else {
            throw new Error(data.message || 'Failed to send message');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert(`Error sending message: ${error.message}\n\nPlease try again later or contact us directly at info@lexingtonassociates.com`);
        
        // Reset button
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
    });
}

// Smooth Scroll for Navigation Links
function setupSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            
            // Skip if it's just a hash
            if (href === '#') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Navbar Background on Scroll
function setupNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
        } else {
            navbar.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
        }
    });
}

// Intersection Observer for Fade-in Animations
function setupFadeInAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe cards and sections
    const cards = document.querySelectorAll(
        '.expertise-card, .people-card, .insight-card, .feature'
    );
    
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
}

// Counter Animation for Stats (if added later)
function animateCounter(element, target, duration = 2000) {
    let current = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Lazy Load Images (if needed)
function setupLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        document.querySelectorAll('img.lazy').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

// Add Active State to Navigation Links
function setupActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (scrollY >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href').slice(1) === current) {
                link.style.color = 'var(--secondary-color)';
            } else {
                link.style.color = 'white';
            }
        });
    });
}

// Initialize All Functions
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Corporate Legal Website...');
    
    // Check disclaimer acceptance
    checkDisclaimerAcceptance();
    
    // Setup all interactive features
    setupMobileMenu();
    setupSmoothScroll();
    setupNavbarScroll();
    setupFadeInAnimations();
    setupLazyLoading();
    setupActiveNavLink();
    
    console.log('Website initialized successfully!');
});

// Handle window resize for responsive design
let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        // Recalculate responsive elements if needed
    }, 250);
});

// Prevent accidental page unload
window.addEventListener('beforeunload', (e) => {
    // Only show warning if user has started filling a form
    const formInputs = document.querySelectorAll('.contact-form input, .contact-form textarea');
    let hasInput = false;
    
    formInputs.forEach(input => {
        if (input.value.trim() !== '') {
            hasInput = true;
        }
    });
    
    if (hasInput) {
        e.preventDefault();
        e.returnValue = '';
    }
});
