# Deployment Guide - Lexington & Associates Website

This guide will help you deploy the website to GitHub Pages (frontend) and Heroku (backend with email integration).

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [GitHub Setup](#github-setup)
3. [Deploy Frontend to GitHub Pages](#deploy-frontend-to-github-pages)
4. [Deploy Backend to Heroku](#deploy-backend-to-heroku)
5. [Configure Email Service](#configure-email-service)
6. [Verify Deployment](#verify-deployment)
7. [Custom Domain Setup](#custom-domain-setup)
8. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before starting, ensure you have:

- A GitHub account (free at https://github.com)
- A Heroku account (free at https://www.heroku.com)
- Git installed on your computer
- Node.js installed (for local testing)
- A Gmail account (for email service)

---

## GitHub Setup

### Step 1: Create a GitHub Repository

1. Go to https://github.com/new
2. Name your repository: `lexington-legal-website`
3. Add description: "Corporate legal website for Lexington & Associates"
4. Choose "Public" (required for free GitHub Pages)
5. Click "Create repository"

### Step 2: Clone and Push Code

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/lexington-legal-website.git

# Navigate to the directory
cd lexington-legal-website

# Copy your website files here
# (Copy index.html, css/, js/, README.md, QUICKSTART.md, DEPLOYMENT.md)

# Add files to git
git add .

# Commit changes
git commit -m "Initial commit: Corporate legal website"

# Push to GitHub
git push origin master
```

---

## Deploy Frontend to GitHub Pages

### Step 1: Enable GitHub Pages

1. Go to your repository on GitHub
2. Click "Settings" (gear icon)
3. Scroll down to "Pages" section
4. Under "Source", select "Deploy from a branch"
5. Select "master" branch and "/ (root)" folder
6. Click "Save"

### Step 2: Wait for Deployment

- GitHub will automatically build and deploy your site
- Your site will be available at: `https://YOUR_USERNAME.github.io/lexington-legal-website`
- This may take 2-5 minutes

### Step 3: Verify Frontend Deployment

1. Visit your GitHub Pages URL
2. Verify all pages load correctly
3. Test navigation and responsive design
4. Note: Contact form won't work yet (backend not deployed)

---

## Deploy Backend to Heroku

### Step 1: Create Heroku App

1. Go to https://dashboard.heroku.com
2. Click "New" → "Create new app"
3. App name: `lexington-backend` (or similar)
4. Region: Choose your region
5. Click "Create app"

### Step 2: Connect GitHub to Heroku

1. In Heroku app dashboard, go to "Deploy" tab
2. Under "Deployment method", click "GitHub"
3. Click "Connect to GitHub"
4. Search for your repository: `lexington-legal-website`
5. Click "Connect"

### Step 3: Enable Automatic Deploys

1. Under "Automatic deploys", click "Enable Automatic Deploys"
2. Select "master" branch
3. Check "Wait for CI to pass before deploy" (optional)
4. Click "Enable Automatic Deploys"

### Step 4: Deploy Backend

1. Click "Deploy Branch" (under "Manual deploy")
2. Wait for deployment to complete (2-5 minutes)
3. You'll see "Your app was successfully deployed"

### Step 5: Get Your Backend URL

1. Click "Open app" button
2. Your backend URL will be in the address bar: `https://lexington-backend.herokuapp.com`
3. Save this URL - you'll need it for configuration

---

## Configure Email Service

### Step 1: Set Up Gmail App Password

1. Go to https://myaccount.google.com/apppasswords
2. Select "Mail" and "Windows Computer" (or your device)
3. Click "Generate"
4. Copy the 16-character password
5. Keep this safe - you'll need it for Heroku

### Step 2: Add Environment Variables to Heroku

1. In Heroku app dashboard, go to "Settings" tab
2. Click "Reveal Config Vars"
3. Add the following variables:

| Key | Value |
|-----|-------|
| EMAIL_USER | your-email@gmail.com |
| EMAIL_PASSWORD | your-16-char-app-password |
| FIRM_EMAIL | info@lexingtonassociates.com |
| NODE_ENV | production |

4. Click "Add" for each variable

### Step 3: Restart Heroku App

1. Go to "More" menu (top right)
2. Click "Restart all dynos"
3. Wait for restart to complete

---

## Update Frontend with Backend URL

### Step 1: Update JavaScript API Endpoint

Edit `js/script.js` and update the API endpoint:

```javascript
// Change this line:
const API_ENDPOINT = process.env.REACT_APP_API_URL || 'https://lexington-backend.herokuapp.com/api/contact';

// To your actual Heroku URL:
const API_ENDPOINT = 'https://your-heroku-app-name.herokuapp.com/api/contact';
```

### Step 2: Commit and Push Changes

```bash
git add js/script.js
git commit -m "Update backend API endpoint"
git push origin master
```

### Step 3: GitHub Pages Auto-Updates

- Your frontend will automatically redeploy
- Wait 2-5 minutes for changes to appear

---

## Verify Deployment

### Test Frontend

1. Visit your GitHub Pages URL
2. Accept the disclaimer
3. Verify all sections load correctly
4. Test mobile responsiveness

### Test Backend

1. Open browser console (F12)
2. Go to your website
3. Fill out the contact form
4. Submit the form
5. Check:
   - Success message appears
   - Email received in your inbox
   - Confirmation email sent to user

### Test Email Integration

1. Submit a test message through the contact form
2. Check your email inbox (FIRM_EMAIL)
3. Check the sender's email inbox for confirmation
4. Verify email formatting and content

---

## Custom Domain Setup

### Option A: Using GitHub Pages Custom Domain

1. In repository Settings → Pages
2. Under "Custom domain", enter your domain: `lexingtonassociates.com`
3. Click "Save"
4. Update your domain's DNS settings (provided by GitHub)

### Option B: Using Namecheap or GoDaddy

1. Purchase a domain
2. In repository Settings → Pages
3. Add your custom domain
4. Update DNS records:
   - A record: `185.199.108.153`
   - A record: `185.199.109.153`
   - A record: `185.199.110.153`
   - A record: `185.199.111.153`

### Option C: Using Cloudflare (Recommended)

1. Add your domain to Cloudflare
2. Update nameservers at your registrar
3. In Cloudflare, create CNAME record:
   - Name: `www`
   - Target: `YOUR_USERNAME.github.io`
   - Proxy status: Proxied

---

## Troubleshooting

### Contact Form Not Sending

**Problem**: Form submission shows error

**Solutions**:
1. Check Heroku app is running: Visit `https://your-heroku-app.herokuapp.com/api/health`
2. Verify environment variables are set in Heroku
3. Check Gmail app password is correct
4. Ensure "Less secure app access" is enabled (if not using app password)

### Backend URL Not Found

**Problem**: 404 error when submitting form

**Solutions**:
1. Verify Heroku app is deployed
2. Check API endpoint in `js/script.js` is correct
3. Ensure backend URL has no trailing slash
4. Test backend directly: `https://your-heroku-app.herokuapp.com/api/health`

### Emails Not Received

**Problem**: Contact form submits but no email arrives

**Solutions**:
1. Check Gmail spam folder
2. Verify EMAIL_USER and EMAIL_PASSWORD in Heroku
3. Ensure FIRM_EMAIL is correct
4. Check Gmail account allows app passwords
5. Try resetting Gmail app password

### GitHub Pages Not Updating

**Problem**: Changes pushed to GitHub but not showing on website

**Solutions**:
1. Clear browser cache (Ctrl+Shift+Delete)
2. Wait 5-10 minutes for GitHub Pages to rebuild
3. Check GitHub Actions tab for build errors
4. Verify files are in root directory of master branch

### Heroku App Sleeping

**Problem**: First request to backend is slow

**Solutions**:
1. This is normal on free Heroku tier
2. Upgrade to paid plan for always-on service
3. Use a service like UptimeRobot to keep app awake

---

## Monitoring and Maintenance

### Check Deployment Status

- **GitHub Pages**: Settings → Pages (shows deployment status)
- **Heroku**: Dashboard → Activity tab (shows recent deployments)

### View Logs

**GitHub Pages Logs**:
1. Go to repository
2. Click "Actions" tab
3. View deployment logs

**Heroku Logs**:
1. In Heroku app dashboard, click "More"
2. Select "View logs"
3. Or use: `heroku logs --tail`

### Update Website

1. Make changes locally
2. Commit and push to GitHub
3. Frontend updates automatically
4. For backend changes, push to GitHub and Heroku redeploys automatically

---

## Upgrade to Custom Domain

Once you have a custom domain:

1. Purchase domain from registrar (Namecheap, GoDaddy, etc.)
2. Update DNS records to point to GitHub Pages
3. Add custom domain to GitHub Pages settings
4. Update backend URL in `js/script.js` if needed
5. Update FIRM_EMAIL in Heroku if using custom email

---

## Security Considerations

1. **Never commit `.env` file** - Only commit `.env.example`
2. **Use environment variables** for sensitive data
3. **Enable HTTPS** (automatic on GitHub Pages and Heroku)
4. **Validate all inputs** on backend (already implemented)
5. **Use CORS** to restrict API access (already configured)

---

## Support

For issues:

1. Check Heroku logs: `heroku logs --tail`
2. Check GitHub Actions for build errors
3. Test backend health: `https://your-app.herokuapp.com/api/health`
4. Review this guide's troubleshooting section
5. Check email service configuration

---

## Next Steps

1. ✅ Deploy frontend to GitHub Pages
2. ✅ Deploy backend to Heroku
3. ✅ Configure email service
4. 📝 Test all functionality
5. 🔗 Set up custom domain (optional)
6. 📊 Add analytics (Google Analytics)
7. 🔒 Enable SSL/TLS (automatic)
8. 📧 Set up email notifications

---

**Deployment Version**: 1.0  
**Last Updated**: June 2, 2026

Good luck with your deployment! 🚀
