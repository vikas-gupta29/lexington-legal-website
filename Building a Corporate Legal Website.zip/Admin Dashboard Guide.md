# Admin Dashboard Guide

## Overview

The Admin Dashboard is an integrated management system for your corporate legal website. It provides real-time monitoring, content management, contact form tracking, analytics, and deployment status monitoring.

**Access URL**: `https://your-website.com/admin.html`  
**Default Password**: `admin123` (Change immediately after first login)

---

## Features

### 1. Overview Dashboard
- **Quick Stats**: View key metrics at a glance
  - Contact submissions count
  - Deployment status
  - Setup progress percentage
  - Team members count
- **Recent Activity**: Track recent events and actions
- **Quick Actions**: Fast access to common tasks

### 2. Deployment Status
Monitor your deployment infrastructure:
- **GitHub Pages Frontend**: Check deployment status and last update time
- **Heroku Backend**: Monitor backend service health and uptime
- **Email Service**: Verify email delivery status and metrics

### 3. Setup Progress Tracker
Track your deployment progress step-by-step:
- Create GitHub Account
- Upload Files to GitHub
- Enable GitHub Pages
- Create Heroku Account
- Configure Email Service
- Test Everything

Mark steps as complete as you progress through setup.

### 4. Content Management
Manage your website content:
- **About Section**: Update firm name, tagline, and description
- **Practice Areas**: Add, edit, or remove practice areas
- **Team Members**: Manage attorney profiles and information
- **Insights**: Publish and manage thought leadership articles

### 5. Contact Submissions
View and manage contact form submissions:
- Search and filter submissions
- View full submission details
- Archive old submissions
- Track submission metrics

### 6. Analytics
View website performance metrics:
- **Traffic Analytics**: Page views, unique visitors, bounce rate
- **Top Pages**: Most visited pages on your website
- **Contact Form Analytics**: Submission metrics and conversion rates
- **Device Breakdown**: Desktop, mobile, and tablet traffic

### 7. Settings
Configure dashboard and website settings:
- **Security**: Change admin password
- **Email Configuration**: Update email settings
- **Deployment Settings**: Configure GitHub and Heroku URLs
- **Backup & Export**: Export data and create backups

---

## Getting Started

### First Login

1. Navigate to `admin.html` on your website
2. Enter the default password: `admin123`
3. Click "Login"
4. **IMPORTANT**: Change your password immediately in Settings

### Changing Your Password

1. Go to **Settings** tab
2. Enter a new password in the "Admin Password" field
3. Click "Update Password"
4. Your new password will be required for future logins

---

## Dashboard Sections

### Overview Tab

The Overview tab provides a quick snapshot of your website's status:

**Stats Cards**:
- Contact Submissions: Total number of form submissions
- Deployment Status: Current status of your website
- Setup Progress: Percentage of setup steps completed
- Team Members: Number of attorneys on your team

**Recent Activity**:
- Shows recent events like new submissions and deployments
- Displays timestamps for each activity

**Quick Actions**:
- Fast access buttons to navigate to other dashboard sections

### Deployment Status Tab

Monitor your deployment infrastructure in real-time:

**GitHub Pages (Frontend)**:
- Website URL
- Deployment status
- Last deployment time
- Repository name
- Refresh button to check current status

**Heroku (Backend)**:
- Backend API URL
- Service status
- Last deployment time
- Uptime percentage
- Dyno type

**Email Service**:
- Email provider (Gmail SMTP)
- Connection status
- Emails sent today
- Delivery rate
- Test email button

### Setup Progress Tab

Track your deployment setup:

**Progress Bar**:
- Visual representation of completion percentage
- Shows current progress out of total steps

**Setup Steps**:
- Each step shows completion status
- Completed steps have a green checkmark
- Current step shows a spinner
- Pending steps show a circle

**Actions**:
- Mark current step as complete
- View full setup guide

### Content Management Tab

Manage your website content:

**About Section**:
- Edit firm name
- Update tagline
- Modify about description
- Save changes

**Practice Areas**:
- View all practice areas
- Edit existing areas
- Add new practice areas
- Remove areas

**Team Members**:
- View all attorneys
- Edit profiles
- Add new team members
- Remove members

**Insights**:
- View published articles
- Edit existing articles
- Publish new articles
- Remove articles

### Contact Submissions Tab

Manage contact form submissions:

**Search & Filter**:
- Search submissions by name or email
- Filter by status (All, Unread, Read, Archived)

**Submission List**:
- Sender name and email
- Submission subject
- Submission date
- Preview of message
- View and Archive buttons

**Actions**:
- Click "View" to see full submission details
- Click "Archive" to remove from active list

### Analytics Tab

View website performance data:

**Website Traffic**:
- Total page views
- Unique visitors
- Average session duration
- Bounce rate

**Top Pages**:
- Home page views
- Expertise page views
- About page views
- Contact page views

**Contact Form Analytics**:
- Total submissions
- Submissions this month
- Conversion rate
- Average response time

**Device Breakdown**:
- Desktop traffic percentage
- Mobile traffic percentage
- Tablet traffic percentage

### Settings Tab

Configure dashboard and website settings:

**Security Settings**:
- Change admin password
- Password must be at least 6 characters

**Email Configuration**:
- Firm email address
- Email provider selection
- Save email settings button

**Deployment Settings**:
- GitHub repository URL
- Heroku app URL
- Save deployment settings button

**Backup & Export**:
- Export submissions as CSV
- Create database backup
- Download files locally

---

## Common Tasks

### Adding a New Practice Area

1. Go to **Content Management** tab
2. Click the **Practice Areas** button
3. Click **"Add New Practice Area"**
4. Fill in the practice area name and description
5. Click **Save**

### Viewing Contact Submissions

1. Go to **Contact Submissions** tab
2. Search or filter submissions as needed
3. Click **"View"** on any submission to see full details
4. Click **"Archive"** to remove from active list

### Checking Deployment Status

1. Go to **Deployment Status** tab
2. View status of GitHub Pages, Heroku, and Email Service
3. Click **"Refresh Status"** buttons to update information
4. All statuses should show "Online" or "Running"

### Exporting Data

1. Go to **Settings** tab
2. Scroll to **Backup & Export** section
3. Click **"Export Data (CSV)"** to download submissions
4. Click **"Backup Database"** to create full backup

### Updating Team Members

1. Go to **Content Management** tab
2. Click the **Team Members** button
3. Click **"Edit"** on any member to modify
4. Click **"Add Team Member"** to add new attorney
5. Fill in name, role, and expertise areas
6. Click **Save**

---

## Security Best Practices

1. **Change Default Password**: Change from `admin123` immediately
2. **Use Strong Passwords**: Use at least 8 characters with mix of letters and numbers
3. **Keep URL Private**: Don't share the admin.html URL publicly
4. **Log Out**: Always log out when finished
5. **Monitor Activity**: Check Recent Activity regularly for suspicious access
6. **Backup Regularly**: Create backups weekly
7. **Update Content**: Keep website content current and accurate

---

## Troubleshooting

### Can't Login

**Problem**: Password not working  
**Solution**: 
- Verify you're using the correct password
- Check for caps lock
- Try resetting password if forgotten

### Deployment Status Shows Offline

**Problem**: GitHub Pages or Heroku showing offline  
**Solution**:
- Click "Refresh Status" button
- Check GitHub and Heroku dashboards directly
- Verify internet connection
- Check email service configuration

### Contact Submissions Not Appearing

**Problem**: Form submissions not showing in dashboard  
**Solution**:
- Verify contact form is working on website
- Check browser console for errors
- Verify backend API is running
- Check email service configuration

### Analytics Not Updating

**Problem**: Analytics data is stale  
**Solution**:
- Refresh the page
- Wait for automatic refresh (every minute)
- Check if Google Analytics is installed
- Verify tracking code is correct

---

## API Endpoints

The dashboard uses these backend API endpoints:

### Dashboard Stats
```
GET /api/dashboard/stats
```
Returns overview statistics

### Deployment Status
```
GET /api/dashboard/deployment/github
GET /api/dashboard/deployment/heroku
GET /api/dashboard/deployment/email
```
Returns deployment status for each service

### Contact Submissions
```
GET /api/dashboard/submissions
GET /api/dashboard/submissions/:id
POST /api/dashboard/submissions/:id/archive
```
Manage contact form submissions

### Analytics
```
GET /api/dashboard/analytics/traffic
GET /api/dashboard/analytics/contact-forms
```
Get analytics data

### Content Management
```
GET /api/dashboard/content
POST /api/dashboard/content/:section
```
Manage website content

### Setup Progress
```
GET /api/dashboard/setup-progress
POST /api/dashboard/setup-progress/:stepId/complete
```
Track setup progress

---

## Advanced Configuration

### Custom Dashboard Password

Set a custom password in your `.env` file:
```
DASHBOARD_PASSWORD=your-secure-password
```

### Custom Email Settings

Configure email service in `.env`:
```
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-password
FIRM_EMAIL=info@yourfirm.com
```

### GitHub and Heroku URLs

Update deployment URLs in `.env`:
```
GITHUB_PAGES_URL=https://username.github.io/lexington-legal-website
HEROKU_APP_URL=https://your-app.herokuapp.com
```

---

## Support & Help

### Dashboard Documentation
- See SETUP_INSTRUCTIONS.md for deployment help
- See DEPLOYMENT.md for technical details
- See README.md for feature overview

### Common Issues
- Check browser console (F12) for errors
- Verify backend API is running
- Check environment variables are set
- Review server logs for errors

### Keyboard Shortcuts
- **Ctrl+L**: Logout (when logged in)
- **Tab**: Navigate between form fields
- **Enter**: Submit forms

---

## Version Information

- **Dashboard Version**: 1.0
- **Last Updated**: June 2, 2026
- **Compatibility**: All modern browsers (Chrome, Firefox, Safari, Edge)

---

## Next Steps

1. ✅ Login to dashboard
2. ✅ Change admin password
3. ✅ Update firm information
4. ✅ Add team members
5. ✅ Configure email settings
6. ✅ Monitor contact submissions
7. ✅ Check deployment status
8. ✅ Review analytics regularly

---

**Happy managing! 🎉**

For questions or issues, refer to the comprehensive documentation or contact your system administrator.
