# Lexington & Associates - Corporate Legal Website

A professional, high-end corporate legal website built with modern web technologies, inspired by leading Indian law firms including AZB & Partners, Cyril Amarchand Mangaldas, and Khaitan & Co.

## Overview

This website represents a premier corporate law firm with a focus on strategic legal counsel, deep sectoral expertise, and thought leadership. The design emphasizes professionalism, trust, and authority while maintaining full compliance with Bar Council of India regulations.

## Features

### 1. **Disclaimer Modal**
- Professional Bar Council of India compliance notice displayed on first visit
- Acknowledgment of no solicitation or advertising
- Persistent storage using localStorage to remember user acceptance
- Comprehensive legal disclaimers and links to Terms of Use and Privacy Policy

### 2. **Navigation**
- Sticky navigation bar with firm branding
- Smooth scrolling to all major sections
- Responsive hamburger menu for mobile devices
- Active link highlighting based on scroll position
- Professional color scheme with gold accents

### 3. **Hero Section**
- Compelling headline: "Driven by Excellence, Focused on Strategic Solutions"
- Subheading highlighting the firm's commitment to Indian enterprises
- Call-to-action button directing to contact section
- Gradient background with subtle wave pattern

### 4. **About Section**
- Firm's purpose and mission statement
- Three key value propositions:
  - Deep Sectoral Expertise
  - Strategic Partnership
  - Innovation & Excellence
- Professional typography and layout

### 5. **Expertise Section**
- 8 major practice areas with icons:
  - Corporate & M&A
  - Capital Markets
  - Banking & Finance
  - Dispute Resolution
  - Energy & Infrastructure
  - Regulatory & Compliance
  - International Trade
  - Employment Law
- Hover effects and smooth animations
- Responsive grid layout

### 6. **People Section**
- Featured attorneys and partners:
  - Rajesh Kumar (Managing Partner)
  - Priya Sharma (Senior Partner - Dispute Resolution)
  - Vikram Desai (Senior Partner - Banking & Finance)
  - Anjali Verma (Partner - Energy & Infrastructure)
- Professional profiles with expertise tags
- Avatar placeholders with gradient backgrounds

### 7. **Thought Leadership Section**
- Recent articles and insights:
  - The Evolution of ESG Compliance in India
  - Cross-Border M&A: Navigating Regulatory Challenges
  - Renewable Energy Projects: Financing and Regulatory Framework
  - Data Protection and Privacy: Compliance in the Digital Age
- Publication dates and "Read More" links
- Left-border accent for visual interest

### 8. **Contact Section**
- Office location details
- Phone and email information
- Professional contact form with validation
- Two-column layout (info + form)
- Blue gradient background with white text

### 9. **Footer**
- Quick links to main sections
- Social media links (LinkedIn, Twitter, Facebook)
- Copyright and legal links
- Professional footer styling

## Technical Stack

### HTML
- Semantic HTML5 structure
- Accessibility considerations
- Meta tags for responsiveness and SEO

### CSS
- Custom CSS with CSS variables for theming
- Mobile-first responsive design
- Flexbox and CSS Grid layouts
- Smooth transitions and animations
- Professional color palette:
  - Primary: #1a3a52 (Dark Blue)
  - Secondary: #c9a961 (Gold)
  - Accent: #2c5aa0 (Medium Blue)

### JavaScript
- Disclaimer modal management with localStorage
- Mobile menu toggle with hamburger animation
- Smooth scroll behavior
- Intersection Observer for fade-in animations
- Form validation and submission handling
- Active navigation link highlighting
- Responsive event listeners

## File Structure

```
legal-website/
├── index.html              # Main HTML file
├── css/
│   └── styles.css         # Complete stylesheet
├── js/
│   └── script.js          # JavaScript functionality
├── images/                # Image assets (placeholder)
├── pages/                 # Additional pages (expandable)
└── README.md              # This file
```

## Key Design Principles

1. **Professionalism**: Clean, sophisticated design reflecting corporate law firm standards
2. **Trust**: Authoritative color scheme and typography
3. **Compliance**: Full Bar Council of India disclaimer compliance
4. **Responsiveness**: Mobile-first design working on all devices
5. **Accessibility**: Semantic HTML and keyboard navigation support
6. **Performance**: Lightweight, fast-loading pages with minimal dependencies
7. **User Experience**: Smooth animations, clear CTAs, and intuitive navigation

## Color Scheme

| Color | Hex | Usage |
|-------|-----|-------|
| Primary Blue | #1a3a52 | Navigation, headers, main text |
| Gold Accent | #c9a961 | Highlights, secondary elements |
| Medium Blue | #2c5aa0 | Links, buttons, accents |
| Light Gray | #f8f9fa | Section backgrounds |
| Dark Gray | #2c3e50 | Body text |
| Light Gray | #7f8c8d | Secondary text |

## Responsive Breakpoints

- **Desktop**: 1200px+ (full layout)
- **Tablet**: 768px - 1199px (adjusted grid, optimized spacing)
- **Mobile**: Below 768px (single column, hamburger menu)
- **Small Mobile**: Below 480px (further optimizations)

## Browser Compatibility

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Customization Guide

### Changing Firm Details
Edit the following in `index.html`:
- Firm name: "Lexington & Associates"
- Contact information in the Contact section
- Attorney names and profiles in the People section
- Practice areas in the Expertise section

### Modifying Colors
Update CSS variables in `css/styles.css`:
```css
:root {
    --primary-color: #1a3a52;
    --secondary-color: #c9a961;
    --accent-color: #2c5aa0;
    /* ... other variables */
}
```

### Adding Content
- Add new practice areas to the Expertise grid
- Add new team members to the People section
- Add new articles to the Thought Leadership section
- Create additional pages in the `pages/` directory

## JavaScript Functions

### `acceptDisclaimer()`
Accepts the disclaimer and shows main content

### `rejectDisclaimer()`
Rejects the disclaimer with alert

### `checkDisclaimerAcceptance()`
Checks localStorage for previous acceptance

### `setupMobileMenu()`
Initializes mobile hamburger menu

### `setupSmoothScroll()`
Enables smooth scrolling for anchor links

### `setupNavbarScroll()`
Updates navbar shadow on scroll

### `setupFadeInAnimations()`
Adds fade-in animations to cards

### `setupActiveNavLink()`
Highlights active navigation link

## Performance Optimization

- No external dependencies (except Font Awesome icons)
- Minimal CSS and JavaScript
- Efficient animations using CSS transforms
- Lazy loading support for images
- Optimized for fast page loads

## SEO Considerations

- Semantic HTML structure
- Descriptive page title
- Meta viewport tag for mobile
- Heading hierarchy (H1, H2, H3)
- Alt text support for images
- Structured content

## Future Enhancements

1. **Blog/Insights Page**: Dedicated page for thought leadership articles
2. **Practice Area Details**: Individual pages for each practice area
3. **Attorney Profiles**: Detailed profiles with qualifications and experience
4. **Client Testimonials**: Success stories and case studies
5. **News & Media**: Press releases and media coverage
6. **Search Functionality**: Site-wide search capability
7. **Multi-language Support**: Hindi and other language versions
8. **CMS Integration**: Dynamic content management
9. **Analytics**: Google Analytics integration
10. **Contact Form Backend**: Email integration for form submissions

## Deployment

### Local Testing
```bash
cd legal-website
python3 -m http.server 8000
# Visit http://localhost:8000
```

### Production Deployment
- Upload files to web hosting
- Ensure HTTPS is enabled
- Configure email for contact form
- Set up analytics tracking
- Test on multiple devices and browsers

## Legal Compliance

This website includes:
- Bar Council of India disclaimer modal
- Acknowledgment of no solicitation
- Legal advice disclaimer
- Intellectual property notice
- Terms of Use and Privacy Policy links

## Support & Maintenance

- Regular content updates
- Monitor for broken links
- Update attorney information
- Add new case studies and insights
- Ensure mobile responsiveness
- Test form submissions

## License

This website template is provided as-is for use by corporate law firms. Modify and customize as needed for your specific requirements.

---

**Created**: June 2026  
**Last Updated**: June 2, 2026  
**Version**: 1.0
