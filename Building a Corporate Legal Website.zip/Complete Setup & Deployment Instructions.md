# Complete Setup & Deployment Instructions

## 🚀 Quick Start (5 Minutes)

This guide will help you deploy your corporate legal website to GitHub Pages (free) with email functionality on Heroku (free tier available).

---

## Step 1: Create GitHub Account & Repository

### 1.1 Create GitHub Account
- Go to https://github.com
- Click "Sign up"
- Complete registration
- Verify your email

### 1.2 Create Repository
- Go to https://github.com/new
- **Repository name**: `lexington-legal-website`
- **Description**: Corporate legal website for Lexington & Associates
- **Visibility**: Public (required for free GitHub Pages)
- Click **"Create repository"**

### 1.3 Get Your Repository URL
- Copy the HTTPS URL (e.g., `https://github.com/YOUR_USERNAME/lexington-legal-website.git`)
- You'll need this in Step 2

---

## Step 2: Upload Website Files to GitHub

### Option A: Using Git Command Line (Recommended)

**Prerequisites**: Install Git from https://git-scm.com

```bash
# Clone your repository
git clone https://github.com/YOUR_USERNAME/lexington-legal-website.git

# Navigate to the directory
cd lexington-legal-website

# Copy all website files here:
# - index.html
# - css/ folder
# - js/ folder
# - backend/ folder
# - README.md
# - DEPLOYMENT.md
# - QUICKSTART.md
# - Procfile
# - .gitignore

# Add all files
git add .

# Commit changes
git commit -m "Initial commit: Corporate legal website with email integration"

# Push to GitHub
git push origin master
```

### Option B: Using GitHub Web Interface

1. Go to your repository on GitHub
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop all files or select them
4. Click **"Commit changes"**

---

## Step 3: Enable GitHub Pages

### 3.1 Access Settings
1. Go to your GitHub repository
2. Click **"Settings"** (gear icon)
3. Scroll down to **"Pages"** section

### 3.2 Configure GitHub Pages
1. Under **"Source"**, select **"Deploy from a branch"**
2. Select **"master"** branch
3. Select **"/ (root)"** folder
4. Click **"Save"**

### 3.3 Get Your Website URL
- Your site will be available at: `https://YOUR_USERNAME.github.io/lexington-legal-website`
- Wait 2-5 minutes for deployment
- Visit the URL to verify it's working

---

## Step 4: Create Heroku Account & App

### 4.1 Create Heroku Account
- Go to https://www.heroku.com
- Click **"Sign up"**
- Complete registration
- Verify your email

### 4.2 Create Heroku App
1. Go to https://dashboard.heroku.com
2. Click **"New"** → **"Create new app"**
3. **App name**: `lexington-backend` (or any unique name)
4. **Region**: Choose your region
5. Click **"Create app"**

### 4.3 Get Your Backend URL
- Your backend URL will be: `https://lexington-backend.herokuapp.com`
- (Replace "lexington-backend" with your app name)

---

## Step 5: Connect GitHub to Heroku

### 5.1 Link GitHub Repository
1. In your Heroku app dashboard, go to **"Deploy"** tab
2. Under **"Deployment method"**, click **"GitHub"**
3. Click **"Connect to GitHub"**
4. Search for your repository: `lexington-legal-website`
5. Click **"Connect"**

### 5.2 Enable Automatic Deployment
1. Under **"Automatic deploys"**, click **"Enable Automatic Deploys"**
2. Select **"master"** branch
3. Click **"Enable Automatic Deploys"**

### 5.3 Deploy Backend
1. Under **"Manual deploy"**, click **"Deploy Branch"**
2. Wait 2-5 minutes for deployment
3. You'll see **"Your app was successfully deployed"**

---

## Step 6: Configure Email Service

### 6.1 Set Up Gmail App Password

**Important**: You must use a Gmail account for this step.

1. Go to https://myaccount.google.com/apppasswords
2. If prompted, sign in to your Google account
3. Select **"Mail"** from the dropdown
4. Select **"Windows Computer"** (or your device type)
5. Click **"Generate"**
6. Copy the **16-character password** shown
7. Save this password somewhere safe

**Note**: If you don't see "App passwords" option:
- Go to https://myaccount.google.com/security
- Enable "2-Step Verification"
- Then try again

### 6.2 Add Environment Variables to Heroku

1. In your Heroku app dashboard, go to **"Settings"** tab
2. Click **"Reveal Config Vars"**
3. Add these variables:

| Key | Value |
|-----|-------|
| EMAIL_USER | your-email@gmail.com |
| EMAIL_PASSWORD | your-16-char-app-password |
| FIRM_EMAIL | info@lexingtonassociates.com |
| NODE_ENV | production |

4. Click **"Add"** button for each variable

### 6.3 Restart Heroku App
1. Click **"More"** menu (top right)
2. Click **"Restart all dynos"**
3. Wait for restart to complete

---

## Step 7: Update Frontend with Backend URL

### 7.1 Edit JavaScript File
1. Go to your GitHub repository
2. Navigate to `js/script.js`
3. Click the **edit icon** (pencil)
4. Find this line (around line 3):
   ```javascript
   const API_ENDPOINT = process.env.REACT_APP_API_URL || 'https://lexington-backend.herokuapp.com/api/contact';
   ```
5. Replace `lexington-backend` with your actual Heroku app name
6. Click **"Commit changes"**

### 7.2 Wait for GitHub Pages Update
- GitHub will automatically rebuild your site
- Wait 2-5 minutes
- Visit your GitHub Pages URL to verify changes

---

## Step 8: Test Your Website

### 8.1 Test Frontend
1. Visit: `https://YOUR_USERNAME.github.io/lexington-legal-website`
2. Accept the disclaimer
3. Verify all sections load correctly
4. Test mobile responsiveness (resize browser)

### 8.2 Test Email Integration
1. Fill out the contact form
2. Submit the form
3. Check:
   - Success message appears
   - Email received in your Gmail inbox
   - Confirmation email sent to the sender

### 8.3 Troubleshooting
- **Form not submitting?** Check browser console (F12) for errors
- **No email received?** Check Gmail spam folder and Heroku logs
- **Backend error?** Visit `https://your-heroku-app.herokuapp.com/api/health`

---

## Step 9: Custom Domain (Optional)

### 9.1 Purchase Domain
- Use Namecheap, GoDaddy, or any registrar
- Popular domains: `.com`, `.co.in`, `.law`

### 9.2 Point Domain to GitHub Pages
1. In your GitHub repository, go to **Settings** → **Pages**
2. Under **"Custom domain"**, enter your domain
3. Click **"Save"**
4. Update your domain's DNS settings (GitHub will provide instructions)

### 9.3 Enable HTTPS
- GitHub Pages automatically enables HTTPS
- This happens automatically after DNS is configured

---

## 📋 Checklist

- [ ] GitHub account created
- [ ] Repository created and files uploaded
- [ ] GitHub Pages enabled
- [ ] Frontend website accessible at GitHub Pages URL
- [ ] Heroku account created
- [ ] Heroku app created
- [ ] GitHub connected to Heroku
- [ ] Backend deployed to Heroku
- [ ] Gmail app password generated
- [ ] Environment variables added to Heroku
- [ ] Frontend updated with backend URL
- [ ] Contact form tested and working
- [ ] Emails being received correctly

---

## 🔗 Important URLs to Save

| Service | URL |
|---------|-----|
| GitHub Repository | https://github.com/YOUR_USERNAME/lexington-legal-website |
| GitHub Pages (Frontend) | https://YOUR_USERNAME.github.io/lexington-legal-website |
| Heroku App (Backend) | https://lexington-backend.herokuapp.com |
| Heroku Dashboard | https://dashboard.heroku.com |

---

## 📧 Email Configuration Details

### What Happens When Someone Submits the Form?

1. User fills out contact form on website
2. Form data sent to Heroku backend
3. Backend validates the data
4. Two emails are sent:
   - **Email 1**: To firm (FIRM_EMAIL) with contact details
   - **Email 2**: To user with confirmation message
5. Success message shown to user

### Email Service Used
- **Service**: Gmail SMTP
- **Sender**: Your Gmail account
- **Recipient 1**: Firm email (configured in Heroku)
- **Recipient 2**: User's email (from form)

---

## 🔒 Security Notes

1. **Never share your app password** publicly
2. **Don't commit `.env` file** to GitHub
3. **Use environment variables** for sensitive data (already configured)
4. **HTTPS is automatic** on both GitHub Pages and Heroku
5. **Input validation** is implemented on backend

---

## 📞 Support & Troubleshooting

### Common Issues

**GitHub Pages not updating?**
- Clear browser cache (Ctrl+Shift+Delete)
- Wait 5-10 minutes
- Check GitHub Actions for errors

**Contact form not working?**
- Check Heroku app is running
- Verify environment variables are set
- Check browser console for errors (F12)

**Emails not received?**
- Check Gmail spam folder
- Verify EMAIL_USER and EMAIL_PASSWORD
- Check Heroku logs for errors

**Backend showing 404?**
- Verify Heroku app is deployed
- Check backend URL in js/script.js
- Test health endpoint: `https://your-app.herokuapp.com/api/health`

---

## 🎉 You're Done!

Your website is now live with:
- ✅ Professional design
- ✅ Responsive layout
- ✅ Working contact form
- ✅ Email integration
- ✅ Free hosting
- ✅ Custom domain ready

### Next Steps

1. **Customize content**: Update firm name, attorneys, practice areas
2. **Add custom domain**: Point your domain to GitHub Pages
3. **Add analytics**: Integrate Google Analytics
4. **Update regularly**: Add blog posts and news
5. **Monitor emails**: Check that contact forms are working

---

## 📚 Additional Resources

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Heroku Documentation](https://devcenter.heroku.com/)
- [Nodemailer Documentation](https://nodemailer.com/)
- [Express.js Guide](https://expressjs.com/)

---

**Version**: 1.0  
**Last Updated**: June 2, 2026  
**Status**: Ready for Deployment

Good luck! 🚀
